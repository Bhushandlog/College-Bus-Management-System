﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Book_Fuel : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnbook_Click(object sender, EventArgs e)
    {
        generate_code();
        Insert_Data();
    }

    private void generate_code()
    {
        string code = "";
    }

    object id;
    private void Insert_Data()
    {
        try
        {
            con.Open();
            string query = String.Format("insert into booking (name, mobile, qty, code) values (@name, @mobile, @qty, @code) select scope_identity();");
            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@name", "");
            cmd.Parameters.AddWithValue("@mobile", "");
            cmd.Parameters.AddWithValue("@qty", txtqty.Text);
            cmd.Parameters.AddWithValue("@code", "");

            id = cmd.ExecuteScalar();
        }
        catch (Exception e1)
        {
            string msg = e1.Message;
        }
        finally
        {
            con.Close();
        }
    }
}